/**
 * this class is responsible to display the energy of the avatar to the player
 *
 * @author Noam shabat, Samuel Hayat
 */
package pepse.world.UI;